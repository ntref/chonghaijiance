function color_Dpq = color_match(Ip,Iq)
% ��ɫ����ƥ��
 

[m,n] = size(Iq);
[m0,n0] = size(Ip);
w = [0.1 0.12 0.08 0.14 0.2 0.1 0.1 0.12 0.04]; % ���ֿ�Ȩֵ
for i = 1:m0
    for j = 1:n0
        D = 0; temp = 0;
        for ii = 1:m
            for jj = 1:n
                if ii == 1
                    D(ii) = D(ii)+sqrt(abs(Ip{i,j}(ii,jj)-Iq(ii,jj)));
                else
                    D(ii) = D(ii-1)+sqrt(abs(Ip{i,j}(ii,jj)-Iq(ii,jj)));
                end
            end
            temp = temp+w(ii)*D(ii);
        end
        color_Dpq(i,j) = temp;
    end
end
color_Dpq